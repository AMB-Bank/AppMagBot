
# AppMag Bot

## Быстрый старт

1. Установи зависимости:
   pip install -r requirements.txt

2. Замени в config.py:
   - TOKEN — на токен от @BotFather
   - PROVIDER_TOKEN — на платёжный токен (Telegram Pay)
   - ADMIN_ID — на свой Telegram ID

3. Запусти бота:
   python main.py

Готово!
