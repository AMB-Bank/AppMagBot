
import sqlite3
from aiogram import Bot, Dispatcher, types
from aiogram.types import ReplyKeyboardMarkup, KeyboardButton, LabeledPrice
from aiogram.utils import executor
from config import TOKEN, PROVIDER_TOKEN, ADMIN_ID
import logging

logging.basicConfig(level=logging.INFO)

bot = Bot(token=TOKEN)
dp = Dispatcher(bot)

conn = sqlite3.connect('users.db')
cursor = conn.cursor()
cursor.execute('''
    CREATE TABLE IF NOT EXISTS users (
        user_id INTEGER PRIMARY KEY,
        username TEXT
    )
''')
cursor.execute('''
    CREATE TABLE IF NOT EXISTS payments (
        payment_id TEXT PRIMARY KEY,
        user_id INTEGER,
        amount INTEGER,
        promo_code TEXT
    )
''')
conn.commit()

keyboard = ReplyKeyboardMarkup(resize_keyboard=True)
keyboard.add(KeyboardButton("Купить валюту"))

PROMO_CODES = {
    "MAGIC50": 0.5,
    "APP10": 0.1
}

@dp.message_handler(commands=['start'])
async def start_handler(message: types.Message):
    user_id = message.from_user.id
    username = message.from_user.username or ""

    cursor.execute("INSERT OR IGNORE INTO users (user_id, username) VALUES (?, ?)", (user_id, username))
    conn.commit()

    await message.answer("Привет! Это AppMag Bot.\nВыберите действие:", reply_markup=keyboard)

@dp.message_handler(lambda message: message.text == "Купить валюту")
async def buy_handler(message: types.Message):
    await message.answer("Если у вас есть промокод, отправьте его сообщением.\nИли напишите 'Нет'.")

@dp.message_handler()
async def handle_promo(message: types.Message):
    text = message.text.strip().upper()
    discount = 0

    if text in PROMO_CODES:
        discount = PROMO_CODES[text]
        await message.answer(f"Промокод принят! Скидка: {int(discount * 100)}%")
    elif text.lower() == "нет":
        await message.answer("Оформляем покупку без промокода.")
    else:
        await message.answer("Неверный промокод. Используем цену по умолчанию.")

    base_price = 500
    final_price = int(base_price * (1 - discount)) * 100

    await message.answer_invoice(
        title="Покупка валюты",
        description="1000 монет AppMag",
        payload=f"order-{message.from_user.id}",
        provider_token=PROVIDER_TOKEN,
        currency="USD",
        prices=[types.LabeledPrice(label="1000 монет AppMag", amount=final_price)],
        start_parameter="appmag-buy",
        photo_url="https://cdn-icons-png.flaticon.com/512/854/854878.png",
        photo_width=512,
        photo_height=512,
        photo_size=512
    )

@dp.pre_checkout_query_handler(lambda query: True)
async def pre_checkout(pre_checkout_query: types.PreCheckoutQuery):
    await bot.answer_pre_checkout_query(pre_checkout_query.id, ok=True)

@dp.message_handler(content_types=types.ContentType.SUCCESSFUL_PAYMENT)
async def payment_success(message: types.Message):
    payment = message.successful_payment
    user_id = message.from_user.id
    promo = "Used" if payment.total_amount < 50000 else "None"

    cursor.execute("INSERT OR REPLACE INTO payments (payment_id, user_id, amount, promo_code) VALUES (?, ?, ?, ?)",
                   (payment.telegram_payment_charge_id, user_id, payment.total_amount, promo))
    conn.commit()

    await message.answer("Платёж прошёл успешно! Валюта зачислена.")

@dp.message_handler(commands=['users'])
async def get_users(message: types.Message):
    if message.from_user.id != ADMIN_ID:
        return await message.answer("Нет доступа.")
    
    cursor.execute("SELECT user_id, username FROM users")
    rows = cursor.fetchall()

    if not rows:
        await message.answer("Нет пользователей.")
    else:
        text = "\n".join([f"{uid} | @{uname}" for uid, uname in rows])
        await message.answer(f"Пользователи:\n{text}")

if __name__ == '__main__':
    executor.start_polling(dp, skip_updates=False)
