
# config.py

TOKEN = 'AAHYxp8moXuUbHS9Qf5ZFGMBY_zsazyQKcs'
PROVIDER_TOKEN = 'YOUR_PAYMENT_PROVIDER_TOKEN'  # заменишь на свой платёжный токен от BotFather
ADMIN_ID = 123456789  # заменишь на свой Telegram ID
